## marktext

Plugin for MarkText, a previewer for Markdown files on Mac OS X

### Requirements

 * [MarkText](https://github.com/marktext/marktext)

### Usage

 * If `marktext` is called without an argument, open MarkText

 * If `marktext` is passed a file, open it in MarkText

### Credits

 * just copied from plugins/marked2, all credits to marked2 plugin author
